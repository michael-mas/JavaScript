Voici un prototype d'un reseau social fait avec REACT et mongoDb.

Vous y trouverez L'API pour le BACK, Le front dans  FRINT-SOCIAL-REACT et dans socket
le fonctionnement du chat avec Socket-IO.

Il manque encore quelques fonctionnalité qui y seront implanté à l'avenir.


ENJOY !